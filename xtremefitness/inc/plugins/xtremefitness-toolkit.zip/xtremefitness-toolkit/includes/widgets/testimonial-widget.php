<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor testimonial Widget.
 *
 * Elementor widget that uses the testimonial control.
 *
 * @since 1.0.0
 */
class Elementor_Testimonial_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve testimonial widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'testimonial';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve testimonial widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'XtremeFitness Testimonial', 'elementor-testimonial-control' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve testimonial widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-carousel-loop';
	}

	/**
	 * Register testimonial widget controls.
	 *
	 * Add input fields to allow the user to customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'elementor-testimonial-control' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'selected_style',
			[
				'label' => esc_html__( 'Select Style', 'elementor-services-post-control' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1', // Set the default style
				'options' => [
					'style1' => esc_html__( 'Style 1', 'elementor-services-post-control' ),
					'style2' => esc_html__( 'Style 2', 'elementor-services-post-control' ),
					'style3' => esc_html__( 'Style 3', 'elementor-services-post-control' ),
				],
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'list_content', [
				'label' => __( 'Content', 'elementor-testimonial-control' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => __( 'Content' , 'elementor-testimonial-control' ),
				'label_block' => true,
				'show_label' => false,
			]
		);
		$repeater->add_control(
			'list_image',
			[
				'label' => esc_html__( 'Image', 'elementor-testimonial-control' ),
				'label_block' => true,
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		$repeater->add_control(
			'list_clientname', [
				'label' => __( 'clientname', 'elementor-testimonial-control' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'clientname' , 'elementor-testimonial-control' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'list_department', [
				'label' => __( 'Department', 'elementor-testimonial-control' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Department' , 'elementor-testimonial-control' ),
				'label_block' => true,
			]
		);
	
		$repeater->add_control(
			'list_image1',
			[
				'label' => esc_html__( 'Quote Image', 'elementor-testimonial-control' ),
				'label_block' => true,
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		$repeater->add_control(
			'list_image2',
			[
				'label' => esc_html__( 'Star Image', 'elementor-testimonial-control' ),
				'label_block' => true,
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
	
		$this->add_control(
			'list',
			[
				'label' => __( 'Repeater List', 'elementor-testimonial-control' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'list_content' => __( 'Content', 'elementor-testimonial-control' ),
						'list_image' => __( 'image', 'elementor-testimonial-control' ),
						'list_clientname' => __( 'Client Name', 'elementor-testimonial-control' ),
						'list_department' => __( 'Department Name', 'elementor-testimonial-control' ),
						'list_image1' => __( 'Quote Image', 'elementor-testimonial-control' ),
					],
					[
						'list_content' => __( 'Content', 'elementor-testimonial-control' ),
						'list_image' => __( 'image', 'elementor-testimonial-control' ),
						'list_clientname' => __( 'Client Name', 'elementor-testimonial-control' ),
						'list_image1' => __( 'Quote Image', 'elementor-testimonial-control' ),
						'list_department' => __( 'Department Name', 'elementor-testimonial-control' ),
					],
				],
				'heading_field' => '{{{ list_heading }}}',
			]
		);
		$this->end_controls_section();
		
	}


	/**
	 * Render testimonial widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$selected_style = $settings['selected_style'];
		?>
		<?php if ($selected_style === 'style1') {?>
			<section class="testimonials_section">
				<div class="container">
					<div class="owl-carousel main-testimonial-carousel owl-theme" data-aos="fade-up" data-aos-duration="700">
					<?php
					$count = 0;
					if ($settings['list']) {
						foreach ($settings['list'] as $item) {
							?>
						<div class="item">
							<div class="testimonials_content">
								<div class="testimonials_apostrophy_wrapper">
									<p><?php echo $item['list_content']; ?></p>
									<figure class="apostrophy mb-0">
										<?php echo wp_get_attachment_image($item['list_image1']['id'], 'full'); ?>
									</figure>
								</div>
								<div class="testimonials_wrapper">
									<h6><?php echo $item['list_clientname']; ?></h6>
									<span><?php echo $item['list_department']; ?></span>
									<figure class="white_line mb-0">
										<?php echo wp_get_attachment_image($item['list_image']['id'], 'full'); ?>
									</figure>
								</div>
							</div>
						</div>
						<?php
								$count++;
							}
						}
						?>
					</div>
				</div>
			</section>
		<?php } if ($selected_style === 'style2') {?>
		<section class="testimonial-section2">
			<div class="container">
				<div class="testimonial-content" data-aos="fade-up" data-aos-duration="700">
					<div class="owl-carousel owl-theme">
					<?php
					$count = 0;
					if ($settings['list']) {
					foreach ($settings['list'] as $item) {
						?>
						<div class="item">
							<div class="client-box">
								<div class="client-img">
									<figure class="mb-0">
										<?php echo wp_get_attachment_image($item['list_image']['id'], 'full'); ?>
									</figure>
								</div>
								<div class="testimonial-right-box">
									<figure class="quote-img">
										<?php echo wp_get_attachment_image($item['list_image1']['id'], 'full'); ?>
									</figure>
									<p><?php echo $item['list_content']; ?></p>
									<div class="client-area">
										<h5><?php echo $item['list_clientname']; ?></h5>
										<span class="d-block"><?php echo $item['list_department']; ?></span>
									</div>
								</div>
							</div>
						</div>
						<?php
								$count++;
							}
						}
						?>
					</div>
					<div class="btn-wrap">
						<button class="prev-btn"><i class="fa-solid fa-angle-left"></i></button>
						<button class="next-btn"><i class="fa-solid fa-angle-right"></i></button>
					</div>
				</div>
			</div>
		</section>
		<?php } if ($selected_style === 'style3') {?>
		<section class="testimonial-section3">
			<section class="testimonial-section2">
				<div class="container">
					<div class="testimonial-content" data-aos="fade-up" data-aos-duration="700">
						<div class="owl-carousel owl-theme">
						<?php
						$count = 0;
						if ($settings['list']) {
						foreach ($settings['list'] as $item) {
							?>
							<div class="item">
								<div class="client-box">
									<div class="client-img">
										<figure class="mb-0">
											<?php echo wp_get_attachment_image($item['list_image']['id'], 'full'); ?>
										</figure>
										<figure class="quote-img">
											<?php echo wp_get_attachment_image($item['list_image1']['id'], 'full'); ?>
										</figure>
									</div>
									<div class="testimonial-right-box">
										<figure class="star-img">
											<?php echo wp_get_attachment_image($item['list_image2']['id'], 'full'); ?>
										</figure>
										<p><?php echo $item['list_content']; ?></p>
										<div class="client-area">
											<h5><?php echo $item['list_clientname']; ?></h5>
											<span class="d-block"><?php echo $item['list_department']; ?></span>
										</div>
									</div>
								</div>
							</div>
							<?php
									$count++;
								}
							}
							?>
						</div>
						<div class="btn-wrap">
							<button class="prev-btn"><i class="fa-solid fa-angle-left"></i></button>
							<button class="next-btn"><i class="fa-solid fa-angle-right"></i></button>
						</div>
					</div>
				</div>
			</section>
		</section>
		<?php } ?>
		<?php
	}
	

}


