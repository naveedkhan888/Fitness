<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * Elementor banner-slider Widget.
 *
 * Elementor widget that uses the banner-slider control.
 *
 * @since 1.0.0
 */
class Elementor_Banner_Slider_Widget extends \Elementor\Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve banner-slider widget name.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'banner-slider';
    }

    /**
     * Get widget title.
     *
     * Retrieve banner-slider widget title.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title()
    {
        return esc_html__('Banner Slider', 'elementor-banner-slider-control');
    }

    /**
     * Get widget icon.
     *
     * Retrieve banner-slider widget icon.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-carousel-loop';
    }

    /**
     * Register banner-slider widget controls.
     *
     * Add input fields to allow the user to customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__('Content', 'elementor-banner-slider-control'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'list_subheading', [
                'label' => __('SubHeading', 'elementor-banner-slider-control'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'XTREME FITNESS',
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'list_heading', [
                'label' => __('Heading', 'elementor-banner-slider-control'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'BE STRONG',
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'list_content', [
                'label' => __('Content', 'elementor-banner-slider-control'),
                'type' => \Elementor\Controls_Manager::WYSIWYG,
                'default' => 'Best GYM & Fitness Center Build Your Health.',
                'label_block' => true,
                'show_label' => false,
            ]
        );
        $repeater->add_control(
            'list_button_text_1',
            [
                'label' => esc_html__('Button Text 1', 'elementor-banner-slider-control'),
                'label_block' => true,
                'type' => 'text',
            ]
        );
        $repeater->add_control(
            'list_button_link_1',
            [
                'label' => esc_html__('Button Link 1', 'elementor-banner-slider-control'),
                'label_block' => true,
                'type' => 'text',
            ]
        );
		$repeater->add_control(
			'list_image1',
			[
				'label' => esc_html__( 'Side Image', 'elementor-testimonial-control' ),
				'label_block' => true,
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
        $this->add_control(
            'list',
            [
                'label' => __('Repeater List', 'elementor-banner-slider-control'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'list_subheading' => 'XTREME FITNESS',
                        'list_heading' => 'BE STRONG',
                        'list_content' => 'Best GYM & Fitness Center Build Your Health.',
                        'list_button_text_1' => 'Join us now',
                        'list_button_link_1' => '#',
						'list_image1' => '#',
                    ],
                    [
                        'list_subheading' => 'XTREME FITNESS',
                        'list_heading' => 'BE STRONG',
                        'list_content' => 'Best GYM & Fitness Center Build Your Health.',
                        'list_button_text_1' => 'Join us now',
						'list_image1' => '#',
                        'list_button_link_1' => '#',
                    ],
                    [
                        'list_subheading' => 'XTREME FITNESS',
                        'list_heading' => 'BE STRONG',
                        'list_content' => 'Best GYM & Fitness Center Build Your Health.',
                        'list_button_text_1' => 'Join us now',
						'list_image1' => '#',
                        'list_button_link_1' => '#',
                    ],
                    [
                        'list_subheading' => 'XTREME FITNESS',
                        'list_heading' => 'BE STRONG',
                        'list_content' => 'Best GYM & Fitness Center Build Your Health.',
                        'list_button_text_1' => 'Join us now',
						'list_image1' => '#',
                        'list_button_link_1' => '#',
                    ],
                ],
                'heading_field' => '{{{ list_heading }}}',
            ]
        );

        $this->end_controls_section();
    }


    /**
     * Render banner-slider widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        ?>
        <section class="banner-section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div id="banner_slider" class="carousel slide" data-ride="carousel">
						<ul class="carousel-indicators">
							<?php
							$count = 0;
							if ($settings['list']) {
								foreach ($settings['list'] as $item) {
							?>
									<li data-target="#banner_slider" data-slide-to="<?php echo $count; ?>" class="<?php if ($count == 0) {echo 'active';} ?>">
									</li>
							<?php
									$count++;
								}
							}
							?>
						</ul>
                            <div class="carousel-inner">
                                <?php
                                $count = 0;
                                if ($settings['list']) {
                                    foreach ($settings['list'] as $item) {
                                ?>
                                        <div class="carousel-item <?php if ($count == 0) {echo 'active';} ?>">
                                            <div class="banner-section-content">
                                                <div class="banner-section-wrapper">
                                                    <h3><?php echo $item['list_subheading']; ?></h3>
                                                    <h1 data-aos="fade-up"><?php echo $item['list_heading']; ?></h1>
                                                    <figure class="white_line mb-0">
														<?php echo wp_get_attachment_image($item['list_image1']['id'], 'full'); ?>
                                                    </figure>
                                                </div>
                                                <p data-aos="fade-right"><?php echo $item['list_content']; ?></p>
                                                <div class="btn_wrapper" data-aos="fade-up">
                                                    <a class="text-decoration-none join_now_btn" href="<?php echo $item['list_button_link_1']; ?>"><?php echo $item['list_button_text_1']; ?>
                                                        <i class="fa-solid fa-play"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                <?php
                                        $count++;
                                    }
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
<?php
    }
}
